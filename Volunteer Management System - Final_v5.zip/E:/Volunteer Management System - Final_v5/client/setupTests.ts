// setupTests.ts
import '@testing-library/jest-dom';  // Import jest-dom to use custom matchers like `toBeInTheDocument`
